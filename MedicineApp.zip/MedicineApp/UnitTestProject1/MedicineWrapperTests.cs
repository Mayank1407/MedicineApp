using MedicineApp.Models;
using MedicineApp.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class MedicineWrapperTests
    {
        [TestMethod]
        public void AddMedicine_Success()
        {
            var medicneWrapper = new MedicineWrapper();
            var medicineModel = new MedicineModel();
            medicineModel.MedicineName = "testname";
            var res = medicneWrapper.AddMedicine(medicineModel).Result;
            Assert.AreEqual(3, res.Count);
        }

        [TestMethod]
        public void GetAllMedicine_Success()
        {
            var medicneWrapper = new MedicineWrapper();
            var res = medicneWrapper.GetAllMedicines().Result;
            Assert.AreEqual(3, res.Count);
        }

        [TestMethod]
        public void GetMedicineByFilter_Success()
        {
            var medicneWrapper = new MedicineWrapper();
            var medicineModel = new MedicineModel();
            medicineModel.MedicineName = "testnameFilter";
            var add = medicneWrapper.AddMedicine(medicineModel).Result;
            var res = medicneWrapper.GetFilteredMedicine(medicineModel.MedicineName).Result;
            Assert.AreEqual(medicineModel.MedicineName, res.MedicineName);
        }
    }
}
