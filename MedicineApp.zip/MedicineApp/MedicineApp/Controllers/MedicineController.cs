﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using MedicineApp.Models;
using MedicineApp.ResponseModel;
using MedicineApp.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace MedicineApp.Controllers
{
    [ApiController]
    [Route("api/medicine")]
    public class MedicineController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IMedicineWrapper medicineWrapper;
        private readonly ILogger<MedicineController> _logger;

        public MedicineController(IMedicineWrapper medicineWrapper, IMapper mapper, ILogger<MedicineController> logger)
        {
            this.medicineWrapper = medicineWrapper;
            _logger = logger;
            _mapper = mapper;
        }
        private static readonly List<MedicineModel> lstMedicine = new List<MedicineModel>
        {
            new MedicineModel() { MedicineName = "Tuna", Brand = "NetMeds" ,Price =50},
            new MedicineModel() { MedicineName = "Corona", Brand = "TestNew" ,Price =70},
        };

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            //var tes = _mapper.Map<MedicineListResponse>(await this.medicineWrapper.GetAllMedicines());
            return Ok(await this.medicineWrapper.GetAllMedicines());
        }

        [HttpGet]
        [Route("{medicinename}")]
        public async Task<IActionResult> GetSpecificMedicine(string medicinename)
        {
            return Ok(await this.medicineWrapper.GetFilteredMedicine(medicinename));
        }

        [HttpPost]
        public async Task<IActionResult> PostMedicine([FromBody] MedicineModel requestModel)
        {
            await this.medicineWrapper.AddMedicine(requestModel);
            return Created("", requestModel);
        }
    }
}
