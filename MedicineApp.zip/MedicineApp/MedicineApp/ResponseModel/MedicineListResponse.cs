﻿using MedicineApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineApp.ResponseModel
{
    public class MedicineListResponse : MedicineCommonModel
    {
        public string Notes { get; set; }
    }
}
