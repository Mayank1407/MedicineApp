﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineApp.Models
{
    public class MedicineCommonModel
    {

        public string MedicineName { get; set; }

        public string Brand { get; set; }

        public Double Price { get; set; }

        public int Quantity { get; set; }

        public DateTime ExpiryDate { get; set; }
    }
}
