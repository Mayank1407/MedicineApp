﻿using MedicineApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineApp.Services
{
    public interface IMedicineWrapper
    {
        Task<List<MedicineModel>> GetAllMedicines();

        Task<MedicineModel> GetFilteredMedicine(string MedicineName);

        Task<List<MedicineModel>> AddMedicine(MedicineModel Medicine);
    }
}
