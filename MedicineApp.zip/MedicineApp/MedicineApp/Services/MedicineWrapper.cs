﻿using AutoMapper;
using MedicineApp.Models;
using MedicineApp.ResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MedicineApp.Services
{
    public class MedicineWrapper : IMedicineWrapper
    {
        private static readonly List<MedicineModel> lstMedicine = new List<MedicineModel>
        {
            new MedicineModel() { MedicineName = "Tuna", Brand = "NetMeds" ,Price =50,Quantity =30,ExpiryDate =DateTime.UtcNow},
            new MedicineModel() { MedicineName = "Corona", Brand = "TestNew" ,Price =70,Quantity =70,ExpiryDate = DateTime.UtcNow.AddDays(-4)},
        };

        public Task<List<MedicineModel>> AddMedicine(MedicineModel Medicine)
        {
            lstMedicine.Add(Medicine);
            return Task.FromResult(lstMedicine);
        }

        public Task<List<MedicineModel>> GetAllMedicines()
        {
            return Task.FromResult(lstMedicine);
        }

        public Task<MedicineModel> GetFilteredMedicine(string MedicineName)
        {
            return Task.FromResult(lstMedicine.FirstOrDefault(x => x.MedicineName == MedicineName));
        }
    }
}
